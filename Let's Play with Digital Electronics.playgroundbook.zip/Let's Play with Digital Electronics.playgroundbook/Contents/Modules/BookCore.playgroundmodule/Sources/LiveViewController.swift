//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  A source file which is part of the auxiliary module named "BookCore".
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport

@objc(BookCore_LiveViewController)

  class FirstScene: UIViewController {
    
      var label = UILabel()
          
      override func loadView() {
         
          let scene = UIView(frame: CGRect(x: 0, y: 0, width: 1366, height: 1024))
          
            scene.sizeToFit()
        
        
        let immagine = UIImageView(frame: CGRect(x: 10, y: scene.layer.position.y, width: scene.frame.width, height: 300))
                 immagine.image = UIImage(named: "transistorSwitch")
        
        
          
          label = UILabel(frame: CGRect(x: immagine.layer.position.x/2, y: immagine.layer.position.y, width: 402, height: 40))
          let fontURL = Bundle.main.url(forResource: "Lovelo-LineBold", withExtension: "ttf")
                 CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
                 let font = UIFont(name: "Lovelo-LineBold", size: 60)
                 
          label.font = font
          label.text = "Hello World"
          label.textColor = .red
          
         
          
          let bottone = UIButton(frame: CGRect(x: immagine.layer.position.x - 35, y: immagine.layer.position.y - 15, width: 60, height: 30))
          bottone.setTitleColor(.black, for: .normal)
          bottone.setTitleColor(.red, for: .highlighted)
          bottone.addTarget(self, action: #selector(self.clicca), for: .touchDown)
          bottone.addTarget(self, action: #selector(self.cliccano), for: .touchUpInside)
          
          
          
          scene.addSubview(label)
          scene.addSubview(immagine)
          scene.addSubview(bottone)
          
          
          self.view = scene
      }
      
      @objc func clicca(){
          //label.text = "acceso"
      }
      
      @objc func cliccano(){
          //label.text = "
    }
}
